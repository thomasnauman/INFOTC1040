print("Thomas Nauman")
print("Age: 19")
print("Home State: MO")
print("Major: Economics")
print("Favorite Color: Blue")


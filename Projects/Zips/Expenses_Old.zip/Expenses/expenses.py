journal_dict = {"Merchandise": [],
                    "Dining": [],
                    "Health Care": [],
                    "Other": [],
                    "Other Services": [],
                    "Other Travel": []}
stat_dict = {}

def parser(csv):
    journal = open(csv, "r+")
    for transaction in journal:
        split = transaction.split(",")
        mess_amount = split[1]
        amount = mess_amount.strip("\n")
        type = split[0]
        journal_dict[type].append(amount)
    journal.close

def find_all_costs():
    total_cost = 0
    for key in journal_dict:
        for index in journal_dict[key]:
            num = round(float(index),2)
            total_cost += num
    stat_dict["total_cost"] = total_cost

def find_num_of_purchases():
    purchases = 0
    for key in journal_dict:
        purchases += (len(journal_dict[key]))
    stat_dict["num_of_purchases"] = purchases

def find_num_of_purchases_for_type():
    for key in journal_dict:
        for index in journal_dict[key]:
            stat_dict[f"{key}_length"] = len(journal_dict[key])

def find_cost_of_purchases_for_type():
    for key in journal_dict:
        cost = 0
        for index in journal_dict[key]:
            num = float(index)
            cost += num
        stat_dict[f"{key}_cost"] = cost

def calculate_average_cost():
    average_cost = stat_dict["total_cost"]/stat_dict["num_of_purchases"]
    stat_dict["average_cost"] = average_cost

def find_min_transaction_cost():
    smallest = 2**31-1
    for key in journal_dict:
        for index in journal_dict[key]:
            if float(index) < float(smallest):
                smallest = index
                smallest_type = key
    stat_dict["smallest"] = smallest
    stat_dict["smallest_type"] = smallest_type

def find_max_transaction_cost():
    largest = -2**31-1
    for key in journal_dict:
        for index in journal_dict[key]:
            if float(index) > float(largest):
                largest = index
                largest_type = key
    stat_dict["largest"] = largest
    stat_dict["largest_type"] = largest_type

def stat_dict_assembler():
    find_all_costs()
    find_num_of_purchases()
    calculate_average_cost()
    find_num_of_purchases_for_type()
    find_cost_of_purchases_for_type()
    find_min_transaction_cost()
    find_max_transaction_cost()

def summary():
    print()
    print(stat_dict)
    print(f"The total cost of all transactions is ${stat_dict['total_cost']:.2f}")
    print(f"The number of purchases is {stat_dict['num_of_purchases']}")
    print(f"The average purchase cost is ${stat_dict['average_cost']:.2f}")
    for key in journal_dict:
        print(f"There were {stat_dict[f'{key}_length']} purchases in {key}")
        print(f"${stat_dict[f'{key}_cost']:2f} was spent on {key}")
    print(f"The least expensive purchase was ${stat_dict['smallest']} spent on {stat_dict['smallest_type']}")
    print(f"The most expensive purchase was ${stat_dict['largest']} spent on {stat_dict['largest_type']}")

def main():
    want_to_continue = True
    while want_to_continue:
        csv = input("What csv file would you like to analyze?: ")
        parser(csv)
        stat_dict_assembler()
        summary()
        repeat = input("Would you like to do another calculation? (y/n): ")
        if repeat != "y":
            want_to_continue = False
            print("All done!")


main()
